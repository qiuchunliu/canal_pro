create
  definer = root@localhost function time_of_uuid64(time datetime) returns bigint
BEGIN
    RETURN  (((unix_timestamp(time)) >> 8 ) << 24  ) | uuid_short() & 0xFF00000000000000;
END;

