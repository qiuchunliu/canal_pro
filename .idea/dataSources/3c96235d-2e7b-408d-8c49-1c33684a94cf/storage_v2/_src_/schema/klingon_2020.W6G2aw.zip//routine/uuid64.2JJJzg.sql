create
  definer = root@`%` function uuid64() returns bigint
BEGIN
  SET @cur_time = unix_timestamp(now());
  SET @suuid = uuid_short();
  SET @epoch = 1532118795;

  RETURN  (((@cur_time) >> 8 ) << 24  ) | (@suuid & 0xFF00000000FFFFFF);
END;

