create
  definer = root@`%` function uuid_bin() returns binary(16)
BEGIN
  RETURN unhex(replace(uuid(), '-', ''));
END;

