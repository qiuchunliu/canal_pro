create definer = root@`%` view work_status as
select `l`.`report_date` AS `work_day`, if((min(`l`.`repay_detail`) = ''), 0, 1) AS `done`
from `klingon_result`.`loan_feedback` `l`
group by `l`.`report_date`;

