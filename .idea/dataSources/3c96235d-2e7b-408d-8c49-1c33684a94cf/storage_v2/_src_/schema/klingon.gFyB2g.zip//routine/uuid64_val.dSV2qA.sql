create
  definer = `5v_user`@`%` function uuid64_val(time datetime) returns bigint unsigned
BEGIN
  SET @cur_time = unix_timestamp(time);
  SET @suuid = uuid_short();
  SET @epoch = 1532118795;

  RETURN  (((@cur_time) >> 8 ) << 24  ) | (@suuid & 0xFF00000000FFFFFF);
END;

