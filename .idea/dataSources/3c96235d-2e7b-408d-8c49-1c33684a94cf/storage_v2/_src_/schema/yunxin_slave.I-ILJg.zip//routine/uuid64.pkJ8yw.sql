create
  definer = root@`%` function uuid64(node tinyint) returns bigint
BEGIN
  SET @cur_time = unix_timestamp(now());
  SET @incr = uuid_short();
  SET @epoch = 1532118795;

  RETURN (node << 56) | ((@cur_time - @epoch) << 24  ) | (@incr & 0xFFFFFF);
END;

