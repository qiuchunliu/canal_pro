create definer = root@`%` view v_np_trade_detail as
select `a`.`host_account_no`                                           AS `ACC_NO`,
       NULL                                                            AS `CURR_COD`,
       date_format(`a`.`transaction_time`, '%Y%m%d')                   AS `TRAN_DATE`,
       date_format(`a`.`transaction_time`, '%H:%i:%s')                 AS `TRAN_TIME`,
       `a`.`remark`                                                    AS `MESSAGE`,
       `a`.`transaction_amount`                                        AS `ACTUAL_AMOUNT`,
       `a`.`balance`                                                   AS `BALANCE_AMOUNT`,
       (case `a`.`account_side` when 0 then '支出' when 1 then '收入' end) AS `MARK`,
       `a`.`counter_account_no`                                        AS `ACCOUNT_NO`,
       `a`.`counter_account_name`                                      AS `ACCOUNT_NAME`,
       `a`.`other_remark`                                              AS `REMARK`,
       `b`.`bank_name`                                                 AS `CADBANK_NM`,
       `a`.`id`                                                        AS `ID`,
       NULL                                                            AS `AMOUNT_TRAN_TYPE`,
       NULL                                                            AS `LAST_TRAN_DATE`,
       NULL                                                            AS `LAST_TRAN_TIME`,
       `a`.`bank_sequence_no`                                          AS `TRAN_NO`,
       `a`.`trade_uuid`                                                AS `CRE_NO`,
       date_format(`a`.`transaction_time`, '%Y%m%d')                   AS `REAL_TRANDATE`,
       concat(`a`.`host_account_no`, `a`.`bank_sequence_no`)           AS `ACC_NO_TRAN_NO`
from (`yunxin_slave`.`cash_flow` `a`
       join `yunxin_slave`.`account` `b`)
where (`a`.`host_account_no` = `b`.`account_no`);

